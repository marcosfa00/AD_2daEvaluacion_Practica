import com.mongodb.client.*;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;
import com.mongodb.internal.bulk.UpdateRequest;
import org.bson.Document;
import org.bson.conversions.Bson;

import javax.print.Doc;

import static com.mongodb.client.model.Filters.eq;

public class Methods {
    /**
     * Conexión con la base de Datos MongoDB
     * @Param database
     * @PAram client
     */
    MongoDatabase database;
    MongoClient mongoClient;


    /**
     * Metodo conexión con la base de datos Mongo
     * @param database Nombre de la base de datos a la que nos vamos a conectar (test)
     */
    public void connectionMongo(String database){
        mongoClient = MongoClients.create();//Creamos el cliente mogno
        this.database = mongoClient.getDatabase(database);
    }

    /**
     * Metodo para obtener todos los datos de una tabla
     */
    public void getNreservas(){
        //OBTENEMOS la tabla (colleccion) de la cual vamos a obtener lso datos
        MongoCollection<Document> collection = database.getCollection("pasaxeiros");
        Bson fields = Projections.fields(
                Projections.include(
                        "nreservas"
                ),
                Projections.excludeId()
        );
        FindIterable<Document> iterable = collection.find().projection(fields);
        MongoCursor<Document> cursor = iterable.iterator();
        //Cuardamos los datos en un documento
        Document doc;

        while (cursor.hasNext()){
            doc = cursor.next();
            System.out.println(doc);

        }

    }

    public void getNReservasByID(String id){
        MongoCollection<Document> collection = database.getCollection("pasaxeiros");

        Bson equals = eq("_id",id);
        FindIterable<Document> iterador = collection.find(equals);
        MongoCursor<Document> cursor = iterador.iterator();

            Document doc = cursor.next();
            int nReservas = doc.getInteger("nreservas");
            System.out.println("NReservas por ID: " +  nReservas);


    }

    public void updateByID(String id){
        MongoCollection<Document> collection = database.getCollection("pasaxeiros");
        Bson query = eq("_id",id);
        Bson change = Updates.combine(
                Updates.set("nreservas",3)
        );
        collection.updateOne(query,change);
    }

    /**
     * Insert en datos
     */
    public void insertMongoDB(){
        Document docIns = new Document("_id",11) //insertamos un nuevo estudiante en la base de datos
                .append("puntuacion",8)
                .append("exame","test")
                .append("estudiante",71)
                ;
        MongoCollection<Document> collection = database.getCollection("datos");
        collection.insertOne(docIns);
    }
    public void createNewParameterByID(String id){
        MongoCollection<Document> collection = database.getCollection("pasaxeiros");
        Bson query = eq("_id",id);
        Bson updade = Updates.set("sexualidad","HeteroSexual macho formido y no Feminista");

      collection.updateOne(query,updade);

    }


}
