public class Main {
    public static void main(String[] args) {
        System.out.println("******PRACTICA MONGO DB *******");
        Methods m = new Methods();
        m.connectionMongo("test");
        m.getNreservas();
        m.getNReservasByID("362b");
       // m.insertMongoDB();
        m.updateByID("364d");
        m.createNewParameterByID("364d");
    }
}