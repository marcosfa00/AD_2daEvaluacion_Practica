package practicaodb;

public class Main {
    public static void main(String[] args) {
        System.out.println("PracticaODB");
        Methods m = new Methods();
        m.conexionODB();
       // m.insert();
      /*  m.countNUsers();
        m.getUsers();
        m.getUserById(2);
        m.updateUserByID(2);
        m.getUserById(2);
        m.updateAll();
        m.getUsers();
        m.deleteAll();*/
        m.getUsers();
        //m.eliminarTodoTypedQuery();
        //m.getUsers();
        m.close();
    }
}