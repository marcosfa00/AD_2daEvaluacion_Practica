package practicaodb;

import javax.persistence.*;
import java.util.List;

public class Methods {

    EntityManager entityManager;

    EntityManagerFactory entityManagerFactory;

    public void conexionODB(){
        entityManagerFactory= Persistence.createEntityManagerFactory("$objectdb/db/practica.odb");
        entityManager = entityManagerFactory.createEntityManager();
    }

    public void insert(){
        entityManager.getTransaction().begin();
        for (int i = 0; i < 3; i++) {
            Users usuario = new Users(
                    ("marcos"+i),
                    ("123"+i)
            );

            entityManager.persist(usuario);

        }
        entityManager.getTransaction().commit();

    }

    public void countNUsers(){
        Query selectCount = entityManager.createQuery("SELECT count(c) FROM Users c ");
        System.out.println("El resultado de la cuenta de filas es : " + selectCount.getSingleResult());
    //TypedQuery<Users> typedQuery = entityManager.createQuery("SELECT t FROM Users t", Users.class);
    }

    public void getUsers(){
        TypedQuery<Users> query = entityManager.createQuery("SELECT u FROM Users u", Users.class);
        List<Users> listaUsuarios = query.getResultList();
        for (Users elemnto : listaUsuarios){

            System.out.println(
               "id: "+  entityManagerFactory.getPersistenceUnitUtil().getIdentifier(elemnto)//devolvemos el id
                    + "-->" + elemnto
            );

        }


    }

    public void getUserById(int id){
        Users user = entityManager.find(Users.class, id);
        if (user!=null){
            System.out.println("ok");
            System.out.println(user);
        }

    }

    public void updateUserByID(int identificador){
        entityManager.getTransaction().begin();

        int update = entityManager.createQuery("UPDATE Users u SET u.name = :newName WHERE u.id = :userId")
                .setParameter("newName", "SAra")
                .setParameter("userId", identificador)
                .executeUpdate();

        entityManager.getTransaction().commit();

        if (update>0){
            System.out.println("se actualizó correctaemnte");
            entityManager.clear();
        }else {
            System.out.println("Error actualizacion");
        }


    }

    public void updateAll(){
        entityManager.getTransaction().begin();
        int update = entityManager.createQuery("UPDATE Users u SET u.password =: pwd WHERE u.password LIKE '%e'")
                .setParameter("pwd","hola")
                        .executeUpdate();
        entityManager.getTransaction().commit();
        if (update>0){
            System.out.println("se actualizó correctaemnte");
            entityManager.clear();
        }else {
            System.out.println("Error actualizacion");
        }


    }

    public void deleteAll(){
        entityManager.getTransaction().begin();
        int update = entityManager.createQuery("DELETE FROM Users u WHERE u.password LIKE '%a'")
                .executeUpdate();
        entityManager.getTransaction().commit();
        if (update>0){
            System.out.println("se actualizó correctaemnte");
            entityManager.clear();
        }else {
            System.out.println("Error actualizacion");
        }


    }

    public void eliminarTodoTypedQuery(){
        entityManager.getTransaction().begin();
        TypedQuery<Users> remove = entityManager.createQuery("SELECT u FROM Users u", Users.class);
        List<Users> listaUsuarios = remove.getResultList();
        for(Users user: listaUsuarios){
            entityManager.remove(user);
        }
        entityManager.getTransaction().commit();

    }



















    public void close(){
        entityManager.close();
        entityManagerFactory.close();
    }


}
