import com.mongodb.client.*;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Sorts;
import com.mongodb.client.model.Updates;
import org.bson.Document;
import org.bson.conversions.Bson;

import java.sql.*;

import static com.mongodb.client.model.Filters.eq;



public class Methods {

    /**
     * Mar 07, 2024 4:36:11 PM com.mongodb.internal.diagnostics.logging.Loggers shouldUseSLF4J
     * WARNING: SLF4J not found on the classpath.  Logging is disabled for the 'org.mongodb.driver' component
     */


    MongoClient mongoClient;
    MongoDatabase database;

    public void connection(String database){
        mongoClient = MongoClients.create();
        this.database = mongoClient.getDatabase(database);

    }

    public void getPasaxeiros(){
        MongoCollection<Document> collection = database.getCollection("pasaxeiros");
        FindIterable<Document> iterable = collection.find();
        MongoCursor<Document> cursor = iterable.iterator();
        Document doc;
        while (cursor.hasNext()){
            doc = cursor.next();
            String nombre = doc.getString("nome");
            System.out.println(doc);
        }
    }

    public void getNreservas(){
        MongoCollection<Document> collection = database.getCollection("pasaxeiros");
        Bson fields = Projections.fields(
                Projections.include(
                        "nome",
                        "cidade",
                        "nreservas"
                ),
                Projections.excludeId()
        );

        FindIterable<Document> iterable = collection.find().projection(fields).sort(Sorts.ascending("_id"));
        MongoCursor<Document> cursor = iterable.iterator();

        while (cursor.hasNext()){
            System.out.println(cursor.next());

        }
    }

    public void getDAtosByID(String id){
        MongoCollection<Document> collection = database.getCollection("pasaxeiros");
        Bson query = eq("_id",id);
        FindIterable<Document> iterable = collection.find(query);
        MongoCursor<Document> cursor = iterable.iterator();
        while (cursor.hasNext()){
            System.out.println(cursor.next());
            updateByID(id);
        }


    }

    public void updateByID(String id){
        MongoCollection<Document> collection = database.getCollection("pasaxeiros");
        Bson query = eq("_id",id);
        Bson update = Updates.combine(
                Updates.set("nome","Marcos"),
                Updates.inc("nreservas",1)

        );
        collection.updateOne(query,update);
    }


    public void insert(){
        Document insert = new Document("_id","365e")
                .append("nome","Marcos")
                .append("cidade","789")
                ;
        MongoCollection<Document> collection = database.getCollection("pasaxeiros");
        collection.insertOne(insert);


    }


    private String driver ="jdbc:postgresql:";
    private String host = "//localhost:";
    private String puerto = "5432";//Recordar que pro defecto en clase será el 5432
    private String sid = "postgres";
    private String usuario="postgres";
    private String password = "postgres";
    private String url = driver + host + puerto + "/" + sid;


    /**
     * Este Metodo devuelve la conexión con la base de datos
     * @return Objecto de Tipo Connection
     */
    public Connection ConexionPost() throws SQLException {
        Connection conn = DriverManager.getConnection(url,usuario,password);
        return conn;

    }

    /**
     * postgres=# select * from reservas;
     *  codr | dni  |  voos
     * ------+------+---------
     *     1 | 361a | (1,2)
     *     2 | 362b | (3,4)
     *     3 | 361a | (5,6)
     *     4 | 363c | (9,10)
     *     5 | 363c | (11,12)
     * (5 rows)
     */

    public void getReservas() throws SQLException {
        String selectQuery = "SELECT *,(voos).* FROM RESERVAS";
        PreparedStatement statement = ConexionPost().prepareStatement(selectQuery);
        ResultSet result = statement.executeQuery();
        while (result.next()){
            int codr = result.getInt("codr");
            int idvueloida = result.getInt("idvooida");
            int idvueloVuelta = result.getInt(" idvoovolta");
        }

    }



















}
