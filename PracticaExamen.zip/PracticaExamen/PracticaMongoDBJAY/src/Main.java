public class Main {
    public static void main(String[] args) {
        System.out.println("MongoDB");
        Methods m = new Methods();
        m.connection("test");
        m.getPasaxeiros();
        m.getNreservas();
        System.out.println("-------------");
        m.getDAtosByID("361a");
       m.updateByID("361a");
       m.getDAtosByID("361a");
       m.insert();

    }
}