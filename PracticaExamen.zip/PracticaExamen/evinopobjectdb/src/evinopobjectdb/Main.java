package evinopobjectdb;

public class Main {
    public static void main(String[] args) {
        System.out.println("evinopobjectdb");
        Methods m = new Methods();
        m.conectionODB();
        m.getAnalisis();
       m.close();
    }
}