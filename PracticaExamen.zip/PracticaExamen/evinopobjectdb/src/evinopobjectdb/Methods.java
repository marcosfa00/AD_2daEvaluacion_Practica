package evinopobjectdb;

import javax.persistence.*;
import java.util.List;

public class Methods {
/**
 * Nos conectamos con objectDB
 */
    EntityManager entityManager;

    EntityManagerFactory entityManagerFactory;

    //Creamos la conexión con ObjectDB
    public void conectionODB(){
        entityManagerFactory = Persistence.createEntityManagerFactory("$objectdb/db/traballos.odb");
        entityManager = entityManagerFactory.createEntityManager();
    }

    /**
     * Analisis es la tabla de referencia
     */
    public void getAnalisis(){
        //Obtenemos todos los datos con TypedQuery
        TypedQuery<Analisis> query = entityManager.createQuery("SELECT a FROM Analisis a", Analisis.class);
        List<Analisis>listaAnalsis = query.getResultList();
        for (Analisis a:listaAnalsis){
            System.out.println(a);
        }
    }


    public void close(){
        entityManager.close();
        entityManagerFactory.close();
    }


}
